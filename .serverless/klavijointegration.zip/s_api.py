import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='serverlessais',
    application_name='klavijointegration',
    app_uid='XFYLC4QbQFNZ14MHhb',
    org_uid='30997690-23a2-4364-8a45-e6e4da72c730',
    deployment_uid='f63f4e6a-cbcf-4055-8916-4226bd51144a',
    service_name='klavijointegration',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'klavijointegration-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
